package com.example.project2nicknevins;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class InventoryManagement extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_management);
    }
}