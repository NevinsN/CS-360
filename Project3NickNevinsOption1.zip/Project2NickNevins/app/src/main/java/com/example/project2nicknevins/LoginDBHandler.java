package com.example.project2nicknevins;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginDBHandler extends SQLiteOpenHelper {
    // Create constant variables
    private static final String DB_NAME = "LoginDB";           // database name
    private static final int DB_VERSION = 1;                   // database version
    private static final String TABLE_NAME = "userLogins";     // table name
    private static final String ID_COLUMN = "id";              // id column
    private static final String USERNAME_COLUMN = "username";  // username column
    private static final String PASSWORD_COLUMN = "password";  // password column

    private static final String SMS_OPT_IN_COLUMN = "sms";     // sms opt in value
    private static final String PHONE_NUMBER_COLUMN = "phone"; // phone number value

    // DB Constructor
    public LoginDBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // Creates database with an sqlite query
    @Override
    public void onCreate(SQLiteDatabase db) {
        // building query to run and create database
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COLUMN + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USERNAME_COLUMN + " TEXT,"
                + PASSWORD_COLUMN + " TEXT,"
                + SMS_OPT_IN_COLUMN + " TEXT,"
                + PHONE_NUMBER_COLUMN + " TEXT)";

        // execute query in sql
        db.execSQL(query);
    }

    // Adds new user to program
    public void addNewUser(String username, String password) {
        // setting variable with our database and calling writable method
        SQLiteDatabase db = this.getWritableDatabase();

        // setting variable with content values
        ContentValues values = new ContentValues();

        // putting values into key/value pairs
        values.put(USERNAME_COLUMN, username);
        values.put(PASSWORD_COLUMN, password);
        values.put(SMS_OPT_IN_COLUMN, "NULL");
        values.put(PHONE_NUMBER_COLUMN, "NULL");

        // inserting values to table
        db.insert(TABLE_NAME, null, values);

        // close database
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // checks if table exists
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Method to check if a username is already in database
    public boolean checkExisting(String username) {
        // new writable database
        SQLiteDatabase db = this.getWritableDatabase();

        // builds query of username column compared to input username then creates cursor
        String query = "SELECT " + USERNAME_COLUMN + " FROM " + TABLE_NAME + " WHERE " + USERNAME_COLUMN + " =?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        // verifies if any results are found and returns true or false
        if (cursor.getCount() > 0) {
            cursor.close();
            db.close();
            return true;
        }
        else {
            cursor.close();
            db.close();
            return false;
        }
    }

    // Method to return smsOptIn for user
    public String getSmsOptInColumn(String username) {
        // new database
        SQLiteDatabase db = this.getWritableDatabase();

        // bulds query to find a user's entry and sets cursor
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + USERNAME_COLUMN + " =?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        // string to return
        String tempHolder = "";

        // moves cursor to first position
        if (cursor.moveToFirst()) {
            tempHolder = cursor.getString(cursor.getColumnIndexOrThrow("sms")); // sets tempHolder with the sms column
        }

        // close database and cursor
        db.close();
        cursor.close();

        return tempHolder;
    }

    // Method to set smsOptIn for user
    public void setSmsOptInColumn(String username, String smsOptIn) {
        // new database
        SQLiteDatabase db = this.getWritableDatabase();

        // build query to locate user's entry by username and creates cursor
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + USERNAME_COLUMN + " =?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        // moves cursor to first position
        if (cursor.moveToFirst()) {
            db.execSQL("UPDATE " + TABLE_NAME + " SET " + SMS_OPT_IN_COLUMN + " = " + smsOptIn); // updates sms column
        }

        // closes cursor and database
        cursor.close();
        db.close();
    }

    // Method to get user's phone number
    public String getPhoneNumberColumn(String username) {
        // new database
        SQLiteDatabase db = this.getWritableDatabase();

        // builds query for user's row and creates cursor
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + USERNAME_COLUMN + " =?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        // string to return
        String tempHolder = "";

        // moves cursor to first position
        if (cursor.moveToFirst()) {
            tempHolder = cursor.getString(cursor.getColumnIndexOrThrow("phone")); // sets tempHolder to phone column
        }

        // closes database and cursor
        db.close();
        cursor.close();

        return tempHolder;
    }

    // Method to set a user's phone number
    public void setPhoneNumberColumn(String username, String phoneNumber) {
        // create new database
        SQLiteDatabase db = this.getWritableDatabase();

        // build query for user's row and creates cursor
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + USERNAME_COLUMN + " =?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        // moves cursor to first position
        if (cursor.moveToFirst()) {
            db.execSQL("UPDATE " + TABLE_NAME + " SET " + PHONE_NUMBER_COLUMN + " = " + phoneNumber); // update's phone number
        }

        // closes cursor and database
        cursor.close();
        db.close();
    }

    // Method to validate a user's login information
    public boolean validateLogin(String username, String password) {
        // new database
        SQLiteDatabase db = this.getWritableDatabase();

        // build query to find a user's username and password entry and build cursor
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + USERNAME_COLUMN + " =? AND " + PASSWORD_COLUMN + " =?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        // Checks if combo was found. Returns true or false.
        if (cursor.getCount() > 0) {
            cursor.close();
            db.close();
            return true;
        }
        else {
            cursor.close();
            db.close();
            return false;
        }
    }
}