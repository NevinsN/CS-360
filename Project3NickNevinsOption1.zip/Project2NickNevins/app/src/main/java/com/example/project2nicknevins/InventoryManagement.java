package com.example.project2nicknevins;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class InventoryManagement extends AppCompatActivity {
    private static final int SMS_PERMISSION = 1; // variable for sms permission
    private String username; // username to be passed screen to screen
    private GridView inventoryGrid; // main gridview
    private ArrayList<String> inventoryArrayList; // ArrayList to hold database information
    private ArrayAdapter<String> inventoryAdapter; // adapter to link ArrayList to gridview
    private InventoryDBHandler dbHandler; // inventory database handler
    private LoginDBHandler loginHandler; // login database handler

    private Button incrementButton, decrementButton, addButton, removeButton; // button variables

    private TextView nameText; // TextView variable for user name
    private int selectedItemID = -1; // stores id of column 0 of selected row

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_management);

        // gets username from previous screen and sets it locally
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            username = extras.getString("user");
        }

        // new login database
        loginHandler = new LoginDBHandler(this);

        // prompts user for sms permissions on first run
        if (loginHandler.getSmsOptInColumn(username).equals("NULL")) {
            getSmsPermissions();
            loginHandler.setSmsOptInColumn(username, "true");
        }

        // links and sets nameText with username
        nameText = findViewById(R.id.nameTextview);
        nameText.setText(username);

        // links inventoryGrid to view
        inventoryGrid = findViewById(R.id.inventoryGrid);

        // initializes buttons
        incrementButton = findViewById(R.id.increaseButton);
        decrementButton = findViewById(R.id.decreaseButton);
        addButton = findViewById(R.id.addItemButton);
        removeButton = findViewById(R.id.removeItemButton);

        // new InventoryDBHandler object
        dbHandler = new InventoryDBHandler(this);

        // populates inventoryArrayList with database
        inventoryArrayList = dbHandler.readInventory();

        // creates the inventorAdapter and sets it to inventoryGrid
        inventoryAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, inventoryArrayList);
        inventoryGrid.setAdapter(inventoryAdapter);

        // gets position of clicked grid view elements and stores as an int in selectedItemID
        inventoryGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                int idPOS = getIDCell(i);
                selectedItemID = Integer.parseInt(inventoryGrid.getItemAtPosition(idPOS).toString());
            }
        });

        // adds onClick logic for the addButton
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Moves to the add item screen
                Intent intent = new Intent(InventoryManagement.this, AddItem.class);
                intent.putExtra("user", username);
                startActivity(intent);
            }
        });

        // adds onClick logic for the removeButton
        removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Checks that a selection has been made, then removes the selection
                if (selectedItemID != -1) {
                    dbHandler.removeItemByID(selectedItemID);
                    reloadInventoryManagement();
                }
                else { // else notifies that a row must be selected
                    Toast.makeText(getBaseContext(), "Please select a row to delete.", Toast.LENGTH_LONG).show();
                }
            }
        });

        // adds onClick logic for the incrementButton
        incrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Checks that a selection has been made, then increments item quantity
                if (selectedItemID != -1) {
                    dbHandler.updateItemByID(selectedItemID, "1");
                    reloadInventoryManagement();
                }
                else { // else notifies that a row must be selected
                    Toast.makeText(getBaseContext(), "Please select a row to modify.", Toast.LENGTH_LONG).show();
                }
            }
        });

        // adds longClick logic for the incrementButton
        incrementButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                // Checks that a selection has been made, then runs promptForNumber
                if (selectedItemID != -1) {
                    promptForNumber(1);
                }
                else { // else notifies that a row must be selected
                    Toast.makeText(getBaseContext(), "Please select a row to modify.", Toast.LENGTH_LONG).show();
                }
                return false;
            }
        });

        // adds onClick logic for the decrementButton
        decrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Checks that a selection has been made
                if (selectedItemID != -1) {
                    // decrements item's quantity
                    dbHandler.updateItemByID(selectedItemID, "-1");
                    // checks for SMS permissions
                    if (ContextCompat.checkSelfPermission(InventoryManagement.this,
                            Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        // checks if the quantity is less than 0
                        if (Integer.parseInt(dbHandler.getQuantityByID(selectedItemID)) <= 0) {
                            sendSmsNotification(username); // sends low inventory notification
                        }
                    }
                    reloadInventoryManagement();
                }
                else { // else notifies that a row must be selected
                    Toast.makeText(getBaseContext(), "Please select a row to modify.", Toast.LENGTH_LONG).show();
                }
            }
        });

        // adds longClick logic for the decrementButton
        decrementButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                // Checks that a selection has been made
                if (selectedItemID != -1) {
                    // runs prompt for number with -1 to cause decrementing
                    promptForNumber(-1);
                    // checks for SMS permissions
                    if (ContextCompat.checkSelfPermission(InventoryManagement.this,
                            Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        // checks if the quantity is less than 0
                        if (Integer.parseInt(dbHandler.getQuantityByID(selectedItemID)) <= 0) {
                            sendSmsNotification(username); // sends low inventory notification
                        }
                    }
                }
                else { // else notifies that a row must be selected
                    Toast.makeText(getBaseContext(), "Please select a row to modify.", Toast.LENGTH_LONG).show();
                }
                return false;
            }
        });
    }

    // Method simply refreshes the inventory screen by renavigating to it
    public void reloadInventoryManagement() {
        Intent intent = new Intent(InventoryManagement.this, InventoryManagement.class);
        intent.putExtra("user", username);
        startActivity(intent);
    }

    // Method calls and AlertDialog and gets a custom number to add or subtract with
    public void promptForNumber(int multiple) {
        EditText numInput; // and EditText for a number

        AlertDialog.Builder numPrompt = new AlertDialog.Builder(this); // new AlertDialog
        final EditText userNumInput = new EditText(InventoryManagement.this); // New EditText
        userNumInput.setInputType(2); // Sets userNumInput to number type

        // sets title and adds userNumInput to numPrompt
        numPrompt.setTitle("Set Number to Modify");
        numPrompt.setView(userNumInput);

        // adds a new layout and sets it to numPrompt
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(userNumInput);
        numPrompt.setView(layout);

        // assigns userNumInput to numInput
        numInput = userNumInput;

        // sets positive button for numPrompt, which will commit an integer to be added or subtracted
        numPrompt.setPositiveButton("Commit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String input = numInput.getText().toString(); // gets input from the EditText
                input = Integer.toString(Integer.parseInt(input) * multiple); // converts to an integer. Multiple is used to make it negative if a -1 is passed through

                // checks for empty input
                if (input.equals("")) {
                    Toast.makeText(getBaseContext(), "Please input a number", Toast.LENGTH_LONG).show();
                }
                else { // else updates quantity by id
                    dbHandler.updateItemByID(selectedItemID, input);
                    // checks for SMS permissions
                    if (ContextCompat.checkSelfPermission(InventoryManagement.this,
                            Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        // checks if the quantity is less than 0
                        if (Integer.parseInt(dbHandler.getQuantityByID(selectedItemID)) <= 0) {
                            sendSmsNotification(username); // sends sms to notify of low inventory
                        }
                    }
                    reloadInventoryManagement();
                }
            }
        });

        // sets negative button, which just closes it
        numPrompt.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });

        // shows the AlertDialog
        numPrompt.show();
    }

    // Method to get an ID cell from any row
    // Uses the selectedItemID's position in the grid view.
    // When you subtract any cell's % 3 from itself, you will always get column 0, the id cell
    public int getIDCell(int i) {
        return i - (i % 3);
    }

    // Method to send an sms message
    public void sendSmsNotification (String username) {
        LoginDBHandler loginHandler = new LoginDBHandler(this); // new login handler
        String phoneNumber = loginHandler.getPhoneNumberColumn(username); // gets user's phonenumber and stores it locally
        String product = dbHandler.getNameByID(selectedItemID); // gets product name from inventoryDB

        // builds message to send
        String message = "Product " + product + " with ID number " + selectedItemID + " is out of stock! Order more soon.";

        // builds SmsManager and sends message
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null );
    }

    // prompts the user fro SEND_SMS permissions
    private void getSmsPermissions() {
        ActivityCompat.requestPermissions(InventoryManagement.this, new String[] {Manifest.permission.SEND_SMS}, SMS_PERMISSION);
    }
}