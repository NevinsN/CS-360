package com.example.project2nicknevins;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // variables for elements and database
    private EditText usernameInput, passwordInput;
    private Button loginButton, newUserButton;
    private LoginDBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialize variables
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        newUserButton = findViewById(R.id.createAccountButton);

        // create LoginDBHandler class and pass context
        dbHandler = new LoginDBHandler(MainActivity.this);

        // adding on click listener to buttons
        newUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // get input from editText field
                String usernameString = usernameInput.getText().toString();
                String passwordString = passwordInput.getText().toString();

                // check if fields are empty
                if (usernameString.isEmpty() || passwordString.isEmpty()) {
                    closeKeyboard();
                    Toast.makeText(MainActivity.this, "Please enter Username and Password.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // check if username exists
                if (dbHandler.checkExisting(usernameString)) {
                    closeKeyboard();
                    Toast.makeText(MainActivity.this, "Username exists. Choose a new username, or try logging in.", Toast.LENGTH_SHORT).show();
                    usernameInput.setText("");
                    passwordInput.setText("");

                    return;
                }

                // use values to add to database
                dbHandler.addNewUser(usernameString, passwordString);

                // Confirms account creation and prompts for login
                Toast.makeText(MainActivity.this, "User created! Please login.", Toast.LENGTH_SHORT).show();
                usernameInput.setText("");
                passwordInput.setText("");

                closeKeyboard();
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // get input from editText field
                String usernameString = usernameInput.getText().toString();
                String passwordString = passwordInput.getText().toString();

                // check if fields are empty
                if (usernameString.isEmpty() || passwordString.isEmpty()) {
                    closeKeyboard();
                    Toast.makeText(MainActivity.this, "Please enter Username and Password.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // check for username/password validation
                if (dbHandler.validateLogin(usernameString, passwordString)) {
                    String smsTest = dbHandler.getSmsOptInColumn(usernameString);

                    if (smsTest.equals("NULL")) {
                        Intent intent = new Intent(MainActivity.this, Notifications.class);
                        intent.putExtra("user", usernameString);
                        startActivity(intent);
                    }
                    else {
                        Intent intent = new Intent(MainActivity.this, InventoryManagement.class);
                        intent.putExtra("user", usernameString);
                        startActivity(intent);
                    }
                }
                else {
                    closeKeyboard();
                    Toast.makeText(MainActivity.this, "Username or Password invalid. Try again or create an account.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void closeKeyboard()
    {
        // get focused view
        View view = this.getCurrentFocus();

        // prevents crash if nothing in focus
        if (view != null) {

            // now assign the system
            // service to InputMethodManager
            InputMethodManager manager
                    = (InputMethodManager)
                    getSystemService(
                            Context.INPUT_METHOD_SERVICE);
            manager
                    .hideSoftInputFromWindow(
                            view.getWindowToken(), 0);
        }
    }
}