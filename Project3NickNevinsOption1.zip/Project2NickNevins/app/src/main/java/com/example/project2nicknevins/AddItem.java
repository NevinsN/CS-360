package com.example.project2nicknevins;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItem extends AppCompatActivity {
    private String username;              // username passed through the app
    private EditText itemName, quantity;  // EditText variables
    private Button addItem, cancel;       // button variables

    private InventoryDBHandler dbHandler; // Inventory dbHandler variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // gets username from previous page and sets it locally
        Bundle extras = getIntent().getExtras();

        // verifies there are extras
        if (extras != null) {
            username = extras.getString("user");
        }

        // variables for UI elements
        itemName = findViewById(R.id.itemNameInput);
        quantity = findViewById(R.id.quantityInput);
        addItem = findViewById(R.id.addButton);
        cancel = findViewById(R.id.cancelButton);

        // sets up dbHandler as new InventoryDBHandler
        dbHandler = new InventoryDBHandler(this);

        // sets onClick for addItem button
        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // variables to work get data from edittext fields
                String itemTemp = itemName.getText().toString();
                String quantTempString = quantity.getText().toString();

                // checks for any empty fields and returns Toast to prompt for fields if needed
                if (itemTemp.equals("") || quantTempString.equals("")) {
                    Toast.makeText(AddItem.this, "Please enter item name and quantity", Toast.LENGTH_SHORT).show();
                }
                else if (testForInt(quantTempString)) { // verifies entry is an int
                    int quantInt = Integer.parseInt(quantTempString); // turns quantity string into int
                    dbHandler.addItem(itemTemp, quantInt); // adds quantInt to inventory db
                    Toast.makeText(AddItem.this, "Item added.", Toast.LENGTH_SHORT).show();
                    returnToInventoryManagement(); // returns to main management page
                }
                else {
                    Toast.makeText(AddItem.this, "Quantity must be an integer.", Toast.LENGTH_SHORT).show(); // alerts user if a non int is entered
                }
            }
        });

        // cancel button on click to return to main inventory screen
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                returnToInventoryManagement();
            }
        });
    }

    // method that tests if an input is an int
    public boolean testForInt(String string) {
        try {
            int num = Integer.parseInt(string);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // method that returns to main inventory screen
    public void returnToInventoryManagement() {
        Intent intent = new Intent(AddItem.this, InventoryManagement.class); // creates intent
        intent.putExtra("user", username); // passes username
        startActivity(intent); // starts intent
    }
}