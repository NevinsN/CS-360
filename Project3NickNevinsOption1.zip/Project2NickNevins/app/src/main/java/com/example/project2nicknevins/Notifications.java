package com.example.project2nicknevins;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Notifications extends AppCompatActivity {

    private String username; // username passed between screens
    private LoginDBHandler dbHandler; // login handler

    private EditText phoneInput; // EditText for user's phone number
    private Button acceptButton, declineButton; // buttons

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        // checks for extras and loads them locally
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            username = extras.getString("user");
        }

        // initializes view elements
        phoneInput = findViewById(R.id.phoneNumberInput);
        acceptButton = findViewById(R.id.acceptButton);
        declineButton = findViewById(R.id.declineButton);

        // initialize loginDB
        dbHandler = new LoginDBHandler(this);

        // creates intent for navigation and passing username
        Intent intent = new Intent(Notifications.this, InventoryManagement.class);
        intent.putExtra("user", username);

        // add onClick logic for accept button
        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // checks if the phone number is empty and is not 10 digits
                if (phoneInput.getText().toString().isEmpty() || phoneInput.getText().toString().length() != 10) {
                    closeKeyboard();
                    Toast.makeText(Notifications.this, "Please enter a valid phone number.", Toast.LENGTH_SHORT).show();
                }
                else {
                    dbHandler.setPhoneNumberColumn(username, phoneInput.getText().toString()); // sets phone number
                    startActivity(intent);
                }
            }
        });

        // adds onClick logic for declineButton
        declineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHandler.setSmsOptInColumn(username, "false");
                startActivity(intent);
            }
        });
    }

    private void closeKeyboard()
    {
        // get view currently in focus
        View view = this.getCurrentFocus();

        // will ensure a view is in focus
        if (view != null) {

            // now assign the system
            // service to InputMethodManager
            InputMethodManager manager
                    = (InputMethodManager)
                    getSystemService(
                            Context.INPUT_METHOD_SERVICE);
            manager
                    .hideSoftInputFromWindow(
                            view.getWindowToken(), 0);
        }
    }
}