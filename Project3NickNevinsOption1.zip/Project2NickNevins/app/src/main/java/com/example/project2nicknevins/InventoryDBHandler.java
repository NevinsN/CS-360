package com.example.project2nicknevins;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.telephony.SmsManager;
import android.widget.Toast;

import java.util.ArrayList;

public class InventoryDBHandler extends SQLiteOpenHelper {
    // Create constant variables
    private static final String DB_NAME = "InventoryDB";          // database name
    private static final int DB_VERSION = 1;                      // database version
    private static final String TABLE_NAME = "inventory";         // table name
    private static final String ID_COLUMN = "id";                 // id column
    private static final String ITEM_NAME_COLUMN = "itemName";     // item name column
    private static final String QUANTITY_COLUMN = "itemQuantity"; // item quantity column

    // DB Constructor
    public InventoryDBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // Creates database with an sqlite query
    @Override
    public void onCreate(SQLiteDatabase db) {
        // building query to run and create database
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COLUMN + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + ITEM_NAME_COLUMN + " TEXT,"
                + QUANTITY_COLUMN + " TEXT)";

        // execute query in sql
        db.execSQL(query);
    }

    // Add an item to database
    public void addItem(String itemName, int quantity) {
        // setting variable with our database and calling writable method
        SQLiteDatabase db = this.getWritableDatabase();

        // setting variable with content values
        ContentValues values = new ContentValues();

        // putting values into key/value pairs
        values.put(ITEM_NAME_COLUMN, itemName);
        values.put(QUANTITY_COLUMN, quantity);

        // inserting values to table
        db.insert(TABLE_NAME, null, values);

        // close database
        db.close();
    }

    // Reads teh database and returns as an ArrayList<String>
    public ArrayList<String> readInventory()
    {
        // create database to work with
        SQLiteDatabase db = this.getReadableDatabase();

        // create cursor to read database
        Cursor inventoryCursor = db.rawQuery("SELECT * FROM inventory", null);

        // ArrayList to hold database items
        ArrayList <String> inventoryArrayList = new ArrayList<String>();
        inventoryArrayList.add("ID");
        inventoryArrayList.add("ITEM NAME");
        inventoryArrayList.add("QUANTITY");

        // variables to aid in adding to ArrayList
        String itemName = "" , quantity = "", id = "";

        // move cursor to first position.
        if (inventoryCursor.moveToFirst()) {
            do {
                // assign database row columns to temp variables
                id = inventoryCursor.getString(inventoryCursor.getColumnIndexOrThrow("id"));
                itemName = inventoryCursor.getString(inventoryCursor.getColumnIndexOrThrow("itemName"));
                quantity = inventoryCursor.getString(inventoryCursor.getColumnIndexOrThrow("itemQuantity"));

                // add inventoryArrayList
                inventoryArrayList.add(id);
                inventoryArrayList.add(itemName);
                inventoryArrayList.add(quantity);

            } while (inventoryCursor.moveToNext()); // move cursor to next
        }

        // close cursor and database. return inventoryArrayList
        inventoryCursor.close();
        db.close();
        return inventoryArrayList;
    }

    // removes an item from the database by id
    public void removeItemByID(int id) {
        // setting variable with our database and calling writable method
        SQLiteDatabase db = this.getWritableDatabase();

        // SQLite command to delete selected item
        db.execSQL("DELETE FROM " + TABLE_NAME + " WHERE " + ID_COLUMN + " = " + id );

        // closes database
        db.close();
    }

    // Method that updates an item's quantity by id
    public void updateItemByID(int id, String value) {
        // setting variable with our database and calling writable method
        SQLiteDatabase db = this.getReadableDatabase();

        // create cursor to read database
        Cursor inventoryCursor = db.rawQuery("SELECT * FROM inventory WHERE id = " + id, null);

        // moves cursor to first position
        if (inventoryCursor.moveToFirst()) {
            // gets a string with item's quantity
            String currentCountString = inventoryCursor.getString(inventoryCursor.getColumnIndexOrThrow("itemQuantity"));

            int currentCountInt = Integer.parseInt(currentCountString); // new int to store currentCountString as an int
            int newCountInt = currentCountInt + Integer.parseInt(value); // new value with value added to currentCountInt

            // if quantity drops below zero, sets quantity to zero
            if (newCountInt < 0) {
                newCountInt = 0;
            }

            // updates quantity
            db.execSQL("UPDATE " + TABLE_NAME + " SET " + QUANTITY_COLUMN + " = " + newCountInt + " WHERE " + ID_COLUMN + " = " + id );
        }

        // close cursor and database
        inventoryCursor.close();
        db.close();
    }

    // Method to get quantity by id
    public String getQuantityByID (int id) {
        // setting variable with our database and calling writable method
        SQLiteDatabase db = this.getReadableDatabase();

        // create cursor to read database
        Cursor inventoryCursor = db.rawQuery("SELECT * FROM inventory WHERE id = " + id, null);

        // string to return
        String tempHolder = "";

        // moves cursor to first position
        if (inventoryCursor.moveToFirst()) {
            tempHolder = inventoryCursor.getString(inventoryCursor.getColumnIndexOrThrow("itemQuantity")); // sets tempHolder to quantity from table
        }

        return tempHolder;
    }

    // Method to get item name by id
    public String getNameByID (int id) {
        // setting variable with our database and calling writable method
        SQLiteDatabase db = this.getReadableDatabase();

        // create cursor to read database
        Cursor inventoryCursor = db.rawQuery("SELECT * FROM inventory WHERE id = " + id, null);

        // string to return
        String tempHolder = "";

        // moves cursor to first position
        if (inventoryCursor.moveToFirst()) {
            tempHolder = inventoryCursor.getString(inventoryCursor.getColumnIndexOrThrow("itemName"));
        }

        return tempHolder;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
